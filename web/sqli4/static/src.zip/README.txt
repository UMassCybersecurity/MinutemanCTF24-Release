To run this locally for testing, run `docker compose up` and go to `localhost:1337`.

See https://docs.docker.com/compose/install/ for installation
